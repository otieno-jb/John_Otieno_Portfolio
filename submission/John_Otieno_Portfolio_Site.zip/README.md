# John Otieno — Portfolio

A dark, vibrant, single-page portfolio built with plain HTML, CSS and JavaScript. No build step and no external runtime dependencies.

## Live

- Short link: <https://is.gd/john_otieno_security>
- Direct URL: <https://elaborate-griffin-326bdf.netlify.app>

The live deployment is an anonymous Netlify preview. See **Deploy** below to claim it or publish under your own account.

## Run locally

```powershell
cd portfolio
python -m http.server 4173 --bind 127.0.0.1
```

Open `http://127.0.0.1:4173/`.

## Structure

```
index.html                 Main portfolio page
styles.css                 Design system and responsive styles
script.js                  Navigation, reveal animations, scrollspy, copy-email
cv.html / cv.css           Print-ready CV source
assets/fonts/              Self-hosted Bricolage Grotesque, Manrope, JetBrains Mono
assets/img/                Portrait, favicon and social card
assets/docs/               Downloadable CV (PDF)
submission/                Capture document, screenshots, QR code and ZIP package
```

## Update contact or social links

Contact details live in `index.html` in the `#contact` section and in the footer. The site currently uses email and telephone because those were the professional links supplied in the CV. Add LinkedIn or GitHub with the same `.contact-row` markup if needed.

## Regenerate the CV PDF

With the local server running:

```powershell
& "C:\Program Files\Google\Chrome\Application\chrome.exe" `
  --headless=new --disable-gpu --no-pdf-header-footer `
  --print-to-pdf="assets/docs/John_Otieno_CV.pdf" `
  "http://127.0.0.1:4173/cv.html"
```

## Deploy

The submission was deployed with Netlify's anonymous deploy flow:

```powershell
netlify deploy --allow-anonymous --dir . --prod --no-build --created-via cli
```

Anonymous sites can be claimed into a Netlify account from the claim URL printed by the CLI. To keep the site permanently, claim it and/or connect a custom domain.

For GitHub Pages, push the contents of this folder to a repository and enable Pages from the `main` branch root.
